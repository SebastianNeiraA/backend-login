import express, { json } from 'express';
import mysql from 'mysql2';
import { corsMiddleware } from './middlewares/cors.js';

const app = express();
app.use(json());
app.use(corsMiddleware());
app.disable('x-powered-by');

// Configura la conexión a la base de datos
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'tienda'
});

db.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conectado a la base de datos');
});

const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

const validatePassword = (password) => {
  const re = /^(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{6,}$/;
  return re.test(password);
};

const validateUsername = (username) => {
  const re = /^[A-Za-z\s]{3,}$/;
  return re.test(username);
};

app.get('/', (req, res) => {
  res.json({ message: 'Hello, World!' });
});

app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.json({ message: "Falta email o contraseña" });
  }

  if (!validateEmail(email)) {
    return res.json({ message: "Email no válido" });
  }

  if (!validatePassword(password)) {
    return res.json({ message: "Contraseña no válida" });
  }

  const query = 'SELECT * FROM users WHERE email = ? AND password = ?';
  db.execute(query, [email, password], (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta:', err);
      return res.json({ message: "Error interno" });
    }

    if (results.length > 0) {
      res.json({ message: "Sesión iniciada correctamente" });
    } else {
      res.json({ message: "Email o contraseña incorrectos" });
    }
  });
});

app.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.json({ message: "Faltan datos para registrar el usuario" });
  }

  if (!validateUsername(username)) {
    return res.json({ message: "Nombre de usuario no válido. Debe tener al menos 3 caracteres y solo contener letras y espacios" });
  }

  if (!validateEmail(email)) {
    return res.json({ message: "Email no válido" });
  }

  if (!validatePassword(password)) {
    return res.json({ message: "La contraseña debe tener al menos 6 caracteres y contener al menos un carácter especial" });
  }

  const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
  db.execute(query, [username, email, password], (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta:', err);
      return res.json({ message: "Error interno" });
    }

    res.json({ message: "Usuario registrado exitosamente" });
  });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log('Server is running on port', PORT);
});
